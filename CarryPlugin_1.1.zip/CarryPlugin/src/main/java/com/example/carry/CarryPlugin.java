package com.example.carry;

import io.papermc.paper.entity.TeleportFlag;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Wither;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDismountEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CarryPlugin extends JavaPlugin implements Listener {

    // ปรับตำแหน่งของที่อุ้มได้ตรงนี้
    private static final double FORWARD = 0.9;  // ระยะห่างไปข้างหน้าจากตัวผู้อุ้ม
    private static final double HEIGHT = 0.7;   // ความสูงจากเท้าผู้อุ้ม (ปรับขึ้น/ลงให้พอดีแขน)

    private static class Carry {
        final UUID carried;
        final ArmorStand stand;
        Carry(UUID carried, ArmorStand stand) {
            this.carried = carried;
            this.stand = stand;
        }
    }

    private final Map<UUID, Carry> carrying = new HashMap<>();   // carrier -> carry
    private final Map<UUID, UUID> carriedBy = new HashMap<>();   // carried -> carrier
    private ItemStack armsItem;
    private int tick = 0;

    @Override
    public void onEnable() {
        // หน้าไม้ที่บรรจุลูกธนู: ฝั่งไคลเอนต์จะวาดท่า "ยกแขนไปข้างหน้า" ให้ผู้เล่นคนอื่นเห็น
        armsItem = new ItemStack(Material.CROSSBOW);
        CrossbowMeta meta = (CrossbowMeta) armsItem.getItemMeta();
        meta.addChargedProjectile(new ItemStack(Material.ARROW));
        armsItem.setItemMeta(meta);

        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 1L, 1L);
    }

    @Override
    public void onDisable() {
        for (UUID id : new ArrayList<>(carrying.keySet())) release(id);
    }

    private void tick() {
        tick++;
        for (UUID carrierId : new ArrayList<>(carrying.keySet())) {
            Carry c = carrying.get(carrierId);
            Player carrier = Bukkit.getPlayer(carrierId);
            Entity carried = Bukkit.getEntity(c.carried);

            if (carrier == null || !carrier.isOnline() || carrier.isDead()
                    || carried == null || carried.isDead() || !c.stand.isValid()
                    || !c.stand.getWorld().equals(carrier.getWorld())) {
                release(carrierId);
                continue;
            }

            // ย้ายแท่นล่องหนไปไว้ที่ "แขน" ด้านหน้าผู้อุ้ม พร้อมของที่อุ้มอยู่
            Location l = carrier.getLocation();
            double yaw = Math.toRadians(l.getYaw());
            Location target = new Location(l.getWorld(),
                    l.getX() - Math.sin(yaw) * FORWARD,
                    l.getY() + HEIGHT,
                    l.getZ() + Math.cos(yaw) * FORWARD,
                    l.getYaw(), 0f);
            c.stand.teleport(target, PlayerTeleportEvent.TeleportCause.PLUGIN,
                    TeleportFlag.EntityState.RETAIN_PASSENGERS);

            // ส่งท่าแขนยื่นไปข้างหน้าให้คนรอบข้างเห็น (ส่งซ้ำเพราะเซิร์ฟเวอร์จะรีเซ็ตเมื่อเปลี่ยนช่องไอเทม)
            if (tick % 4 == 0) showArms(carrier, armsItem);
        }
    }

    private void showArms(Player carrier, ItemStack item) {
        for (Player v : carrier.getWorld().getPlayers()) {
            if (v.equals(carrier)) continue;
            if (v.getLocation().distanceSquared(carrier.getLocation()) > 64 * 64) continue;
            v.sendEquipmentChange(carrier, EquipmentSlot.HAND, item);
        }
    }

    // กดย่อ + คลิกขวาใส่เอนทิตี้: อุ้ม (หรือวางถ้ากำลังอุ้มอยู่)
    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        if (!p.isSneaking() || !p.hasPermission("carry.use")) return;

        if (carrying.containsKey(p.getUniqueId())) {
            e.setCancelled(true);
            release(p.getUniqueId());
            return;
        }

        Entity target = e.getRightClicked();
        if (!canCarry(p, target)) return;
        e.setCancelled(true);

        Location l = p.getLocation();
        ArmorStand stand = l.getWorld().spawn(l, ArmorStand.class, s -> {
            s.setVisible(false);
            s.setMarker(true);
            s.setGravity(false);
            s.setInvulnerable(true);
            s.setSilent(true);
            s.setPersistent(false);
        });

        if (stand.addPassenger(target)) {
            carrying.put(p.getUniqueId(), new Carry(target.getUniqueId(), stand));
            carriedBy.put(target.getUniqueId(), p.getUniqueId());
            showArms(p, armsItem);
        } else {
            stand.remove();
        }
    }

    // กดย่อ + คลิกขวาที่บล็อก/อากาศ (ตอนถือไอเทม): วาง
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        if (!p.isSneaking() || !carrying.containsKey(p.getUniqueId())) return;
        e.setCancelled(true);
        release(p.getUniqueId());
    }

    // กันคนที่ถูกอุ้มลงจากแท่นเอง (เช่นกดย่อ)
    @EventHandler
    public void onDismount(EntityDismountEvent e) {
        if (carriedBy.containsKey(e.getEntity().getUniqueId()) && e.isCancellable()) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        release(id);
        UUID carrier = carriedBy.get(id);
        if (carrier != null) release(carrier);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        release(e.getEntity().getUniqueId());
    }

    private boolean canCarry(Player p, Entity target) {
        if (target.equals(p)) return false;
        if (!(target instanceof LivingEntity) || target instanceof ArmorStand) return false;
        if (target instanceof EnderDragon || target instanceof Wither) return false;
        if (target.hasPermission("carry.bypass")) return false;
        if (p.isInsideVehicle() || carriedBy.containsKey(p.getUniqueId())) return false;
        if (target.isInsideVehicle() || !target.getPassengers().isEmpty()) return false;
        if (carrying.containsKey(target.getUniqueId())) return false;
        return true;
    }

    private void release(UUID carrierId) {
        Carry c = carrying.remove(carrierId);
        if (c == null) return;
        carriedBy.remove(c.carried);

        Player carrier = Bukkit.getPlayer(carrierId);
        Entity carried = Bukkit.getEntity(c.carried);

        Location drop = null;
        if (carrier != null && carrier.isOnline()) {
            Location l = carrier.getLocation();
            double yaw = Math.toRadians(l.getYaw());
            drop = l.clone().add(-Math.sin(yaw) * 1.2, 0, Math.cos(yaw) * 1.2);
            showArms(carrier, carrier.getInventory().getItemInMainHand()); // คืนท่าแขนปกติ
        }

        if (carried != null) {
            c.stand.removePassenger(carried);
            if (drop != null) {
                drop.setYaw(carried.getLocation().getYaw());
                drop.setPitch(carried.getLocation().getPitch());
                carried.teleport(drop);
            }
        }
        c.stand.remove();
    }
}

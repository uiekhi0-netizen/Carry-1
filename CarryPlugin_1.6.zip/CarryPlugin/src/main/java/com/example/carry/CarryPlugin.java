package com.example.carry;

import io.papermc.paper.entity.TeleportFlag;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Wither;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDismountEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CarryPlugin extends JavaPlugin implements Listener {

    // ปรับตำแหน่งของที่อุ้มได้ตรงนี้
    private static final double FORWARD = 0.9;  // ระยะห่างไปข้างหน้าจากตัวผู้อุ้ม
    private static final double HEIGHT = 0.7;   // ความสูงจากเท้าผู้อุ้ม (ปรับขึ้น/ลงให้พอดีแขน)

    private static class Carry {
        final UUID carried;
        final ArmorStand stand;
        Carry(UUID carried, ArmorStand stand) {
            this.carried = carried;
            this.stand = stand;
        }
    }

    private final Map<UUID, Carry> carrying = new HashMap<>();   // carrier -> carry
    private final Map<UUID, UUID> carriedBy = new HashMap<>();   // carried -> carrier
    private ItemStack armsItem;
    private NamespacedKey markerKey;
    private NamespacedKey backupKey;

    @Override
    public void onEnable() {
        markerKey = new NamespacedKey(this, "carry_arms");
        backupKey = new NamespacedKey(this, "offhand_backup");

        // หน้าไม้ที่บรรจุลูกธนู ถือไว้ที่มือซ้าย: ไคลเอนต์จะวาดท่า "ยกสองแขนไปข้างหน้า"
        armsItem = new ItemStack(Material.CROSSBOW);
        CrossbowMeta meta = (CrossbowMeta) armsItem.getItemMeta();
        meta.addChargedProjectile(new ItemStack(Material.ARROW));
        meta.getPersistentDataContainer().set(markerKey, PersistentDataType.BYTE, (byte) 1);
        armsItem.setItemMeta(meta);

        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 1L, 1L);
    }

    @Override
    public void onDisable() {
        for (UUID id : new ArrayList<>(carrying.keySet())) release(id);
    }

    private void tick() {
        for (UUID carrierId : new ArrayList<>(carrying.keySet())) {
            Carry c = carrying.get(carrierId);
            Player carrier = Bukkit.getPlayer(carrierId);
            Entity carried = Bukkit.getEntity(c.carried);

            if (carrier == null || !carrier.isOnline() || carrier.isDead()
                    || carried == null || carried.isDead() || !c.stand.isValid()
                    || !c.stand.getWorld().equals(carrier.getWorld())) {
                release(carrierId);
                continue;
            }

            // ย้ายแท่นล่องหนไปไว้ที่ "แขน" ด้านหน้าผู้อุ้ม พร้อมของที่อุ้มอยู่
            Location l = carrier.getLocation();
            double yaw = Math.toRadians(l.getYaw());
            Location target = new Location(l.getWorld(),
                    l.getX() - Math.sin(yaw) * FORWARD,
                    l.getY() + HEIGHT,
                    l.getZ() + Math.cos(yaw) * FORWARD,
                    l.getYaw(), 0f);
            c.stand.teleport(target, PlayerTeleportEvent.TeleportCause.PLUGIN,
                    TeleportFlag.EntityState.RETAIN_PASSENGERS);
        }
    }

    // ---------- ท่ายกแขน (สลับของในมือซ้ายชั่วคราว แล้วคืนให้ตอนวาง) ----------

    private boolean isMarker(ItemStack i) {
        if (i == null || i.getType() != Material.CROSSBOW || !i.hasItemMeta()) return false;
        return i.getItemMeta().getPersistentDataContainer().has(markerKey, PersistentDataType.BYTE);
    }

    private void giveArms(Player p) {
        ItemStack old = p.getInventory().getItemInOffHand();
        if (!isMarker(old)) {
            byte[] data = old.getType().isAir() ? new byte[0] : old.serializeAsBytes();
            p.getPersistentDataContainer().set(backupKey, PersistentDataType.BYTE_ARRAY, data);
        }
        p.getInventory().setItemInOffHand(armsItem.clone());
    }

    private ItemStack readBackup(Player p) {
        byte[] b = p.getPersistentDataContainer().get(backupKey, PersistentDataType.BYTE_ARRAY);
        if (b == null) return null;
        return b.length == 0 ? new ItemStack(Material.AIR) : ItemStack.deserializeBytes(b);
    }

    private void restoreOffhand(Player p) {
        ItemStack orig = readBackup(p);
        if (orig != null) {
            p.getPersistentDataContainer().remove(backupKey);
            p.getInventory().setItemInOffHand(orig);
        } else if (isMarker(p.getInventory().getItemInOffHand())) {
            p.getInventory().setItemInOffHand(new ItemStack(Material.AIR));
        }
    }

    // ---------- อุ้ม / วาง ----------

    // กดย่อ + คลิกขวาใส่เอนทิตี้: อุ้ม (หรือวางถ้ากำลังอุ้มอยู่)
    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        if (!p.isSneaking() || !p.hasPermission("carry.use")) return;

        if (carrying.containsKey(p.getUniqueId())) {
            e.setCancelled(true);
            release(p.getUniqueId());
            return;
        }

        Entity target = e.getRightClicked();
        if (!canCarry(p, target)) return;
        e.setCancelled(true);

        Location l = p.getLocation();
        ArmorStand stand = l.getWorld().spawn(l, ArmorStand.class, s -> {
            s.setVisible(false);
            s.setMarker(true);
            s.setGravity(false);
            s.setInvulnerable(true);
            s.setSilent(true);
            s.setPersistent(false);
        });

        if (stand.addPassenger(target)) {
            carrying.put(p.getUniqueId(), new Carry(target.getUniqueId(), stand));
            carriedBy.put(target.getUniqueId(), p.getUniqueId());
            giveArms(p);
        } else {
            stand.remove();
        }
    }

    // กดย่อ + คลิกขวาที่บล็อก/อากาศ: วาง (และกันหน้าไม้ปลอมยิงลูกธนู)
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        if (!carrying.containsKey(p.getUniqueId())) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        if (e.getHand() == EquipmentSlot.OFF_HAND) {
            e.setCancelled(true);
            return;
        }
        if (p.isSneaking()) {
            e.setCancelled(true);
            release(p.getUniqueId());
        }
    }

    @EventHandler
    public void onShoot(EntityShootBowEvent e) {
        if (isMarker(e.getBow())) e.setCancelled(true);
    }

    // กันเอาหน้าไม้ปลอมออกจากมือซ้าย ระหว่างอุ้ม
    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (carrying.containsKey(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (isMarker(e.getItemDrop().getItemStack())) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (carrying.containsKey(e.getWhoClicked().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (carrying.containsKey(e.getWhoClicked().getUniqueId())) e.setCancelled(true);
    }

    // กันคนที่ถูกอุ้มลงจากแท่นเอง (เช่นกดย่อ)
    @EventHandler
    public void onDismount(EntityDismountEvent e) {
        if (carriedBy.containsKey(e.getEntity().getUniqueId()) && e.isCancellable()) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!carrying.containsKey(p.getUniqueId())) restoreOffhand(p); // กันของหายถ้าเซิร์ฟเวอร์ดับตอนอุ้ม
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        release(id);
        UUID carrier = carriedBy.get(id);
        if (carrier != null) release(carrier);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        UUID id = p.getUniqueId();
        if (!carrying.containsKey(id)) return;

        e.getDrops().removeIf(this::isMarker);
        if (e.getKeepInventory()) {
            release(id, true);
        } else {
            ItemStack orig = readBackup(p);
            p.getPersistentDataContainer().remove(backupKey);
            if (orig != null && !orig.getType().isAir()) e.getDrops().add(orig);
            release(id, false);
        }
    }

    private boolean canCarry(Player p, Entity target) {
        if (target.equals(p)) return false;
        if (!(target instanceof LivingEntity) || target instanceof ArmorStand) return false;
        if (target instanceof EnderDragon || target instanceof Wither) return false;
        if (target.hasPermission("carry.bypass")) return false;
        if (p.isInsideVehicle() || carriedBy.containsKey(p.getUniqueId())) return false;
        if (target.isInsideVehicle() || !target.getPassengers().isEmpty()) return false;
        if (carrying.containsKey(target.getUniqueId())) return false;
        return true;
    }

    private void release(UUID carrierId) {
        release(carrierId, true);
    }

    private void release(UUID carrierId, boolean restoreOffhand) {
        Carry c = carrying.remove(carrierId);
        if (c == null) return;
        carriedBy.remove(c.carried);

        Player carrier = Bukkit.getPlayer(carrierId);
        Entity carried = Bukkit.getEntity(c.carried);

        Location drop = null;
        if (carrier != null && carrier.isOnline()) {
            if (restoreOffhand) restoreOffhand(carrier); // คืนของในมือซ้าย + ท่าแขนกลับเป็นปกติ
            Location l = carrier.getLocation();
            double yaw = Math.toRadians(l.getYaw());
            drop = l.clone().add(-Math.sin(yaw) * 1.2, 0, Math.cos(yaw) * 1.2);
        }

        if (carried != null) {
            c.stand.removePassenger(carried);
            if (drop != null) {
                drop.setYaw(carried.getLocation().getYaw());
                drop.setPitch(carried.getLocation().getPitch());
                carried.teleport(drop);
            }
        }
        c.stand.remove();
    }
}
